### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ekzebiche/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ekzebiche/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9773c9fcbe3221179dad/maintainability)](https://codeclimate.com/github/Ekzebiche/python-project-49/maintainability)
