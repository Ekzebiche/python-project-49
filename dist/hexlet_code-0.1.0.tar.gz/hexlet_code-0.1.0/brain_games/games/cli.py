from brain_games.common import utils


def welcome_user():
    utils.find_out_name()
