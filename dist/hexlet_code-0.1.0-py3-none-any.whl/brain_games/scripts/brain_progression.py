from brain_games.games.progression import start


def main():
    start()


if __name__ == "__main__":
    main()
